# javascript-basics
This repo has simple programs for beginners starting their programming journey in JavaScript. It has a simple login page program which helps understand simple concepts of taking input from the user, etc.
